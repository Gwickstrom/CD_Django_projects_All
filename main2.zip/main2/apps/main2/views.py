from django.shortcuts import render

# Create your views here.
def index(request):
    context = {
        "email" : "blob@gmail.com",
        "name": "mike"
    }
    return render(request, 'main2/index.html', context)

def show(request, id):
    context = {
        "id" : id
    }
    return render(request, 'main2/show.html', context)
