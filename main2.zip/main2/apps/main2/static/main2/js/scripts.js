console.log('hello world');
alert('This is awesome and easy');
