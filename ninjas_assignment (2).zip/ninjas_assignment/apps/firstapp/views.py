from django.shortcuts import render, HttpResponse

# Create your views here.
def index(request):
    return render(request,'firstapp/index.html')

def show(request, ninja_color):
    turtle_options = {
        'red':'firstapp/raphael.jpg',
        'blue':'firstapp/leonardo.jpg',
        'orange':'firstapp/michaelangelo.jpg',
        'purple':'firstapp/donatello.jpg'
    }
    if ninja_color in turtle_options:
        context = {
            'image':turtle_options[ninja_color]
        }
    else:
        context = {
            'image':'firstapp/april.jpg'
        }
    """
    A less concise version:
    if ninja_color == 'red':
        context= {
            'image':'firstapp/raphael.jpg'
        }
    elif ninja_color == 'blue':
        context= {
            'image':'firstapp/leonardo.jpg'
        }
    elif ninja_color == 'purple':
        context= {
            'image':'firstapp/donatello.jpg'
        }
    elif ninja_color == 'orange':
        context= {
            'image':'firstapp/michaelangelo.jpg'
        }
    else:
        context= {
            'image':'firstapp/april.jpg'
        }
    """
    # context in this line is so that the index.html can use the keys and values of context. They do this by saying {% load staticfiles %} and {% if image <img src="{% static image %} alt =""/> {% endif %}%} or {{image}}
    return render(request,'firstapp/index.html',context)

def noshow(request):
    print ("No Ninjas Here")
    return HttpResponse("No Ninjas Here")
