from django.shortcuts import render, redirect
from django.shortcuts import HttpResponse
from django import forms
from django.contrib.sessions.models import Session

import random

# Create your views here.
# request.session['counter'] = {0:""}

def index(request):
    if 'activity' in request.session:
        pass
    else:
        request.session['activity'] = []
    return render(request,'ninjagold/index.html')

def sessionCounter(request):
    if 'counter' in request.session:
        request.session['counter'] += result
    else:
        request.session['counter'] = 0



def process_money(request):
    counter = 0
    random_results = {
        "farm": random.randint(10,20),
        "cave": random.randint(10,20),
        "house": random.randint(10,20),
        "casino": random.randint(10,20),
    }
    if(request.POST['building']) == 'farm':
        context = {
            'gold_count': 'random_results[farm]'
        }

#
    elif (request.POST['building']) == "cave":
        context = {
            'gold_count':'random_results[cave]'
        }

    elif (request.POST['building']) == "house":
        context = {
            'gold_count':'random_results[house]'
        }
    elif (request.POST['building']) == "casino":
        context = {
            'gold_count':'random_results[casino]'
        }
    elif (request.POST['building']) == "reset":
        request.session['counter'] = 0

        request.session['gold_count'] += request.session['gold_count']
    return render(request, 'ninjagold/index.html', context)
    return redirect('/')


    #Counts the amount of times a user has triggered it [1]

    # TEMPORARILY COMMENTED OUT
    # def test_count_session(request):
    #     if 'count' in request.session:
    #         request.session['count'] += 1
    #         return HttpResponse('new count=%s' % request.session['count'])
    #     else:
    #         request.session['count'] = 1
    #         return HttpResponse('No count in session. Setting to 1')

    # def process_money(request):
    #     if(request.POST['building']) == 'farm':
    #         random_num = random.randint(10,20)
    #         sessionCounter(request.session['random_num'])
    #         request.session['activity'].append(result)
    #     elif (request.POST['building']) == "cave":
    #         random_num = random.randint(5,10)
    #         sessionCounter(request.session['random_num'])
    #     elif (request.POST['building']) == "house":
    #         random_num = random.randint(2,5)
    #         sessionCounter(request.session['random_num'])
    #     elif (request.POST['building']) == "casino":
    #         random_num = random.randint(-50,50)
    #         sessionCounter(request.session['random_num'])
    #     elif (request.POST['building']) == "reset":
    #         request.session['counter'] = 0
    #     return redirect('/')
