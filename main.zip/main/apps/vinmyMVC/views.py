from django.shortcuts import render, redirect

# Create your views here.
def index(request):
    return render(request, 'vinmyMVC/index.html')

def show(request):
    print(request.method)
    return render(request, 'vinmyMVC/show_users.html')

def create(request):
    print(request.method)
    if request.method == "POST":
        print ('*'*50)
        print (request.POST)
        print ('*'*50)
        request.session['name'] = request.POST['first_name']
        return redirect('/')
    else:
        return redirect('/')
#from time display
# from datetime import date, time, tzinfo
# from datetime import datetime, timedelta
# from pytz import timezone
# from time import strftime
# import datetime
# import pytz


# today = datetime.date.today().strftime("%b %d, %Y")
# print today
#
#
# utc = pytz.utc
# utc.zone
# pacific = timezone('US/Pacific')
# curtime = pacific.localize(datetime.datetime.now())
# pacific_curtime = curtime.astimezone(pacific).strftime("%I : %M %p")
#
# print pacific_curtime

# utc_dt = datetime.datetime.now(fmt, tzinfo=utc)
# loc_dt = utc_dt.astimezone(pacific)
# loc_dt.strftime(fmt)
