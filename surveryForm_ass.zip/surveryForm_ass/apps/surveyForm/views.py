from django.shortcuts import render, redirect
from django.conf import settings
from django.views.generic.edit import FormView
from django.views.generic import FormView
from django import forms
import re
from django.db.models import Q


class ContactForm(forms.Form):
    contact_name = forms.CharField(required=True)
    location = forms.CharField(required=True)
    language = forms.CharField(required=True)
    comment = forms.CharField(widget=forms.Textarea)
    content = forms.CharField(required=True, widget=forms.Textarea )
    submit = forms.CharField(required=True)

def index(request):
    # form = SearchForm()
    # if request.method == "POST":
    #     f = SearchForm(request.POST)
    #     if f.is_valid():
    #         Pets = Pet.objects.filter(animal = f.cleaned_data["text"])
    #         return HttpResponseRedirect("results.html",{"contact_name":Contact_name},{"form":form})
    if not 'attempt' in request.session:
        request.session['attempt'] = 0
        if request.method == 'POST':
            form = form_class(data=request.POST)
            if any in inform.is_valid():
                contact_name = request.POST.get('contact_name', '')
                location = request.POST.get('location', '')
                language = request.POST.get('language', '')
                comment = request.GET.get('comment', '')
                form_content = request.POST.get('content', '')
                template = get_template('index.html')
                context = Context [{
                    'contact_name': contact_name,
                    'location': location,
                    'language': language,
                    'comment': comment,
                }]
                content = template.render(context)
                return context

                for i in context.itervalues():
                    if not i in request.session['context']:
                        return render(request, 'surveyForm/results.html')
                    else:
                        request.session['attempt'] += 1
                        return render(request, 'surveyForm/index.html')
    return render(request, '')
# def search_page(request):
#     form = SearchForm()
#     if request.method == "POST":
#         f = SearchForm(request.POST)
#         if f.is_valid():
#             Pets = Pet.objects.filter(animal = f.cleaned_data["text"])
#             return HttpResponseRedirect("results.html",{"contact_name":Contact_name},{"form":form})



    return render_to_response("search.html",{"form":form} , context_instance = RequestContext(request))
def contact(request):
    form_class = ContactForm
    for i in range(0, len(['form_content'] - 1)):
        if request.method == 'POST':
            form = ContactForm(request.POST)
            if form.is_valid():
                print form.cleaned_data['my_form_fieldname']
            return redirect('/')
        else:
            return redirect('/')
    return render(request, 'surveyForm/results.html')

def iterateattempt(request):
	for i in range(0, len(['form_content'] - 1)):
	    request.session['attempt'] += 1
	    return redirect('/')


# def selected_choice(form, field_name):
#     return render('request.session['form_content']':'(form.fields[field_name].choices)[form.data[field_name]]'
#     return render(request, 'surveyForm/results.html')



def reset(request):
	del request.session['attempt']
	del request.session['context']
	return redirect('/')

# def index(request):
#     if not 'attempt' in request.session:
#         request.session['attempt'] = 0
    #     if request.method == 'POST':
    #         form = form_class(data=request.POST)
    #             if any c inform.is_valid():
    #             \        contact_name = request.POST.get('contact_name', '')
    #                     location = request.POST.get('location', '')
    #                     language = request.POST.get('language', '')
    #                     comment = request.GET.get('comment', '')
    #                     form_content = request.POST.get('content', '')
    #                     template = get_template('index.html')
    #                     context = Context({
    #                         'contact_name': contact_name,
    #                         'location': location,
    #                         'language': language,
    #                         'comment': comment,
    #                     })
    #                     content = template.render(context)
    #                     content
    #                     return redirect('/results')
#
#     return render(request, 'index.html', { 'form': form_class,
#         })
#         form_content = request.session['form_content']
#         form_content = {
#             request.session['contact_name']: 'None',
#             request.session['location']: 'None',
#             request.session['language']: 'None',
#             request.session['comment']: 'None'
# #             }




#

#--------------stuff from online------------------
#
# def contact2(request):
#     for i in range(0, len(['form_content'] - 1)):
#         if request.method == 'POST':
#             form = ContactForm(request.POST)
#             if form.is_valid():
#                 print form.cleaned_data['my_form_fieldname']
#                 return HttpResponseRedirect('/')
#         else:
#             print form.cleaned_data['my_form_fieldname']
#             return HttpResponseRedirect('/')


# 1. to get users data from the form, may need to be apart of a larger function


# 2. FormView either in surveyform/forms.py or views.py

# 3. FormView in views.py

#4 HttpRequest.method
