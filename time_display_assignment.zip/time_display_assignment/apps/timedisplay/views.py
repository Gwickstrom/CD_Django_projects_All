from django.shortcuts import render, HttpResponse
from datetime import timedelta
import datetime, time

# Create your views here.
def index(request):
    i = datetime.datetime.now()
    currentDateTime = ("%s/%s/%s" % (i.day,i.month,i.year)) + (" %d:%d" % (i.hour,i.minute))

    noon = datetime.datetime.now()
    noonInFull = ("%s/%s/%s" % (noon.day,noon.month,noon.year)) + (" %s:%s:%s" % (12,00,00))
    empty = ""
    if currentDateTime < noonInFull:
        empty = "AM"

    else:
        empty = "PM"

    today = i.strftime("%b %d, %Y")
    todaytime = i.strftime("%I:%M")
    context= {
    "today":today,
    "todaytime":todaytime,
    "empty":empty
    }
    return render(request, 'timedisplay/index.html', context)
