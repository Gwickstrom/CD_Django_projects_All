from django.conf.urls import url
from . import views

urlpartterns = [
    url(r'^$', views.index),
    # url(r'^$', views.logout),
    # url(r'^$', views.login),
    url(r'^success$', views.success),
    url(r'^success$', views.register, name = 'register'),
    url(r'^success/(?P<posts>\d+)$', views.posts),
    url(r'^success$', views.comments, name = 'comments'),
]
