from django.shortcuts import render, redirect
from django.shortcuts import HttpResponse
import re
EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
# Create your views here.
#@app.route('/')
def index(request):
    # user_id = request.session['user_id']
    if 'user_id' in request.session:
        return render(request, "thewall/success.html")
    else:
        return redirect('/')


def register(request):
    errors = []
    # 1. check first_name of length
    if len(request.POST['first_name']) < 2:
        errors.append('First name field must be at least 2 charactors long')
    # 2. check last_name of length
    if len(request.POST['last_name']) < 2:
        errors.append('Last name field must be at least 2 charactors long')
    # 3. check email exist
    if not request.POST['email']:
        errors.append('Email is required')
    # 4. check email is valid
    if not EMAIL_REGEX.match(request.POST['email']):
        errors.append('Email must be valid')
    # 5. check password exist
    if not request.POST['password']:
        errors.append('Password is required')
    # 6. check password length
    if len(request.POST['password']) < 8:
        errors.append('Password field must be at least 8 charactors long')
    # 7. check password matched confirm_password
    if not request.POST['password'] == request.POST['confirm_password']:
        errors.append('Password fields must match')
    # 8. check for email existances
    query = 'SELECT * FROM users WHERE email = :email'
    data = {'email': request.POST['email']}
    user = mysql.query_db(query, data)

    if user:
        errors.append('Email already exist')

    # check for errors
    if error in errors:
        for error in errors:
            return HttpResponse(['errors'])
        return redirect('/')
    else:
        # Passed all validations, store the user is session, redirect to success page
        password = bcrypt.generate_password_hash(request.POST['password'])
        query = 'INSERT into users (first_name, last_name, email, password, created_at, updated_at) VALUES (:first_name, :last_name, :email, :password, NOW(), NOW())'
        data = {
            'first_name': request.POST['first_name'],
            'last_name': request.POST['last_name'],
            'email': request.POST['email'],
            'password': password
        }
        # will get user_id back from insert command
        user_id = mysql.query_db(query, data)
        # save user_id for later user
        request.session['user_id'] = user_id

        return render(request, 'thewall/success.html')

# route for success page
def success(request):
    if 'user_id' not in request.session:
        return HttpRespone('Must be logged in to continue')
        return redirect('/')
        query = 'SELECT posts.content, users.first_name, users.last_name, posts.created_at FROM posts JOIN users on posts.user_id = users.id'
        posts = mysql.query_db(query)

        query = 'SELECT comments.posts_id, comments.content, comments.created_at, users.first_name, users.last_name from comments JOIN users on comments.user_id = users.id'
        comment = mysql.query_db(query)
    else:
        return render(request, 'thewall/success.html')

#@app.route('/logout', methods=['POST'])
def logout():
    request.session.clear()
    return redirect('/')

#@app.route('/login', methods=['POST'])
def login():
    # check for a saved email
    query = 'SELECT * FROM users WHERE email = :email'
    data = {'email': request.POST['email']}
    user = mysql.query_db(query, data)
    if user:
        # check email from post and password match what is in db
        print user
        if bcrypt.check_password_hash(user[0]['password'], request.POST['password']):
            # save the user in session
            request.session['user_id'] = user[0]['id']
            return render(request, 'thewall/success.html')
        else:
            return HttpResponse('Invalid email/ password combination')
    else:
        return HttpResponse('Invalid email')
        return redirect('/')

# -------------------------- Routes of the wall ---------------------

#@app.route('/posts', methods=['post'])
def posts(request, posts):
    id = request.POST['posts']
    content = request.POST['context']
    context = {
    'posts': "posts",
    'content': "content",
    }
    query = 'INSERT into posts (user_id, content, created_at, updated_at) VALUES (:user_id, :content, NOW(), NOW())'

    mysql.query_db(query, data)
    return render(request, "thewall/success.html", context)

#@app.route('/comments/<post_id>', methods=['POST'])
def comments(request):
    user_id = request.session['user_id']
    data = {
        'user_id': user_id,
        'post_id': post_id,
        'content': request.POST['content']
    }
    query = 'INSERT into comments (user_id, post_id, content, created_at, updated_at) VALUES (:user_id, :post_id, :content, NOW(), NOW())'
    mysql.query_db(query, data)

    return redirect('/success')
